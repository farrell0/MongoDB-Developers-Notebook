#!/bin/bash


l_pwd=`pwd`/30_SupportScripts


#
#  Stop all processes
#
kafka-server-stop.sh                  2> /dev/null > /dev/null
zookeeper-server-stop.sh              2> /dev/null > /dev/null

#
#  Nuke for morbid, delete all (old) log files.
#
rm -fr /tmp/kafka-logs /tmp/zookeeper

#
#  Start all processes
#
zookeeper-server-start.sh /opt/kafka_2.11-0.10.1.0/config/zookeeper.properties \
   2> /dev/null > /dev/null &
sleep 10
kafka-server-start.sh /opt/kafka_2.11-0.10.1.0/config/server.properties \
   2> /dev/null > /dev/null &
sleep 10




################################################################

#
#  Commented this whole block out.
#

#
#  Get a list of all topics, and delete them
#
# for l_topic in `"${l_pwd}/06_GetAllTopics.sh"`
#    do
#    "${l_pwd}"/07_DeleteATopic.sh $l_topic
#    done

#
#  Stop all processes
#
# kafka-server-stop.sh                  2> /dev/null > /dev/null
# zookeeper-server-stop.sh              2> /dev/null > /dev/null

#
#  Start all processes
#
# zookeeper-server-start.sh /opt/kafka_2.11-0.10.1.0/config/zookeeper.properties \
#    2> /dev/null > /dev/null &
# sleep 10
# kafka-server-start.sh /opt/kafka_2.11-0.10.1.0/config/server.properties \
#    2> /dev/null > /dev/null &




