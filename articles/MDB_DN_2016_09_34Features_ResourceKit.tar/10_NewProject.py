

import pymongo
   #
from pymongo import MongoClient


######################################################


cn = MongoClient("localhost:28000, localhost:28001, localhost:28002")
db = cn.test_db9

db.my_coll.drop()
   #
db.my_coll.insert( { "k1" : 1, "k2" : 2 } )


sss = list ( db.my_coll.find( {}, { "_id" : 0 } ) )
for s in sss:
   print s

sss = list ( db.my_coll.aggregate(
   [
   { "$project" : { "_id" : 0 } }
   ]
   ) )
for s in sss:
   print s


db.my_coll.drop()


#
#  Returns
#
#  {u'k2': 2, u'k1': 1}
#  {u'k2': 2, u'k1': 1}
#


