

import pymongo
   #
from pymongo import MongoClient


######################################################


cn = MongoClient("localhost:28000, localhost:28001, localhost:28002")
db = cn.test_db9

db.my_coll.drop()
   #
db.my_coll.insert( { "price" : 10 } )
db.my_coll.insert( { "price" : 10 } )
db.my_coll.insert( { "price" : 10 } )
db.my_coll.insert( { "price" : 20 } )
db.my_coll.insert( { "price" : 20 } )
db.my_coll.insert( { "price" : 50 } )


######################################################


print "  "
print "Example: $sortByCount stage in aggregate."
print "  "
sss = list ( db.my_coll.aggregate(
   [
   {
   "$sortByCount" : "$price"
   }
   ] ) )
for s in sss:
   print s


