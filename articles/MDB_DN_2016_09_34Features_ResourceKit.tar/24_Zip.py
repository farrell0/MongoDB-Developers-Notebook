

import pymongo
   #
from pymongo import MongoClient


######################################################


cn = MongoClient("localhost:28000, localhost:28001, localhost:28002")
db = cn.test_db9

db.my_coll.drop()
   #
db.my_coll.insert( {
   "category"     : "Computer peripherals"   ,
   "sub-category" : "Mouse"                  ,
   "attributes"   :
      [
      { "color"   : "red"       },
      { "buttons" : 3           }
      ],
   "other"        :
      [
      { "ship"    : "International okay" },
      { "tax"     : "Yes"                },
      ]
   } )
db.my_coll.insert( {
   "category"     : "Computer peripherals"   ,
   "sub-category" : "Mouse"                  ,
   "attributes"   :
      [
      { "color"   : "blue"      },
      { "plug"    : "USB"       },
      { "buttons" : 2           }
      ],
   "other"        :
      [
      { "ship"    : "Domestic only"      },
      ]
   } )


######################################################


print "  "
print "Example: $zip operator in aggregate."
print "  "
sss = list ( db.my_coll.aggregate(
   [
   {
   "$project"                  : 
      {
      "_id"                    : 0,
         #
      "newArr"                 : 
         { 
         "$zip"                : 
            {
            "inputs"           : [ "$attributes", "$other" ],
            "defaults"         : [ 0, 1],
            "useLongestLength" : True
            }
         }
      }
   }
   ] ) )
for s in sss:
   print s























