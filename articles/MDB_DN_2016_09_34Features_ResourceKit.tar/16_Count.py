

import pymongo
   #
from pymongo import MongoClient


######################################################


cn = MongoClient("localhost:28000, localhost:28001, localhost:28002")
db = cn.test_db9

db.my_coll.drop()
   #
db.my_coll.insert( { "price" : 10 } )
db.my_coll.insert( { "price" : 10 } )
db.my_coll.insert( { "price" : 10 } )
db.my_coll.insert( { "price" : 20 } )
db.my_coll.insert( { "price" : 20 } )
db.my_coll.insert( { "price" : 50 } )


######################################################


print "  "
print "Example: $count stage in aggregate."
print "  "
sss = list ( db.my_coll.aggregate(
   [
   {
   "$match" : 
      {
      "price" : { "$gte" : 12 }
      }
   },
   {
   "$count" :  "price" 
   }
   ] ) )
for s in sss:
   print s


######################################################


print "  "
print "Example: $count stage in group/aggregate."
print "  "
sss = list ( db.my_coll.aggregate(
   [
   {
   "$match" : 
      {
      "price" : { "$gte" : 12 }
      }
   },
   {
   "$group" :
      {
      "_id"        : "null",
      "my_count1"  : { "$sum" : 1 }             # ,
      # "my_count2"  : { "$count" : "$price" }  # This operator was not known
      }
   }
   ] ) )
for s in sss:
   print s








