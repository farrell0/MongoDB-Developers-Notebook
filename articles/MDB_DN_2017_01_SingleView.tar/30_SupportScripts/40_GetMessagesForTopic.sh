#!/bin/bash



kafka-console-consumer.sh --bootstrap-server localhost:9092 \
   --topic $1 --from-beginning --timeout-ms 50 \
   2> /dev/null







