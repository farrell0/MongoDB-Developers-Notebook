



from kafka import KafkaProducer


producer = KafkaProducer()


producer.send('x_MDB', "RT RT RT")
producer.send('t1'   , "RT RT RT")
producer.send('t4'   , "RT RT RT")





