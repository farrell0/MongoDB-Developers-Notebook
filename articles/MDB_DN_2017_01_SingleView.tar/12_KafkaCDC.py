

#
#  This program reads from a Kafka topic and propagates
#  changes into a mongoDB database server instance.
#
#
#  Comments-
#
#  .  Version 0.67
#
#  .  This program was tested on CentOS 7 64 bit, and a
#     Kafka version 0.10.1.
#
#     All software is expected to be running on one host,
#     as was this test program.
#
#  .  This program loops, gets all of the Kafka topic
#     names starting with the letter 't', and listens
#     for messages, which are then upserted into mongoDB.
#
#  .  To push messages into a Kafka queue, run any of 
#     the following,
#
#        Add a topic
#           kafka-topics.sh --create --zookeeper localhost:2181 \
#              --replication-factor 1 --partitions 1 --topic t1
#
#        List topics
#           kafka-topics.sh --list --zookeeper localhost:2181
#
#        Delete topic
#           kafka-topics.sh --zookeeper localhost:2181 \
#              --delete --topic t1 --force
#
#        Produce a message
#           echo "Blah blah " | kafka-console-producer.sh \
#              --broker-list localhost:9092 --topic t1
#
#        Consume a message
#           kafka-console-consumer.sh --bootstrap-server \
#              localhost:9092 --topic t1 --from-beginning
#           kafka-console-consumer.sh --bootstrap-server \
#              localhost:9092 --topic t1
#




##################################################################
## Imports #######################################################


import pymongo
import kafka
   #
import time
import threading
import subprocess                 #  Run Linux programs
   #
import ast                        #  Convert string to JSON




##################################################################
## Define functions ##############################################


#
#  Messages received from Kafka
#
l_kMsgs = []
   
#
#  Kafka topics we monitor
#
l_topics = [ "t1", "t2", "t3", "t4",
   "t5", "t6", "t7", "t8", "x_MDB" ]

#
#  Create a topic inside Kafka
#
def add_topic(p_arg1):
   l_proc = subprocess.Popen([
      './30_SupportScripts/08_AddATopic.sh', p_arg1])
         #
   l_proc.communicate()




##################################################################
## Recycle Kafka #################################################


#
#  Nuke for morbid; stop and restart Kafka and its associated
#  Zookeeper.
#

print "  "
print "Recycle Kafka: Begin (about 28 seconds)"
   #
l_proc = subprocess.Popen([
   './30_SupportScripts/04_StartAllKafka.sh', ' '])
l_proc.communicate()
   #
print "Recycle Kafka: End"

print "  "

for l_topic in l_topics:
   print "Add Kafka topic: " + l_topic
   add_topic(l_topic)




##################################################################


mongo_host = pymongo.MongoClient("localhost:27017")
mdb        = mongo_host.test_sv




##################################################################
## Program main ##################################################


print "  "
print "Running: Kafka CDC (12)  (Consume t*)"
print "  "

#
#  Polling from Kafa topics.
#
#  The Python lib we used for this had some issues;
#
#  .  The subscribe pattern returned all topics.
#     So we need to filter those out.
#  .  The start from beginning did not work, so
#     we run this task async, and place the results
#     in an array.
#

class t_tab3(threading.Thread):
   global l_kMsgs
      #
   daemon = True

   def run(self):
      l_messages = kafka.KafkaConsumer()
      l_messages.subscribe(pattern="t*")
            #
      for l_message in l_messages:
         l_message = str(l_message.value)
         l_message = ast.literal_eval(l_message)
            #
         l_kMsgs.append(l_message)

l_threads = [ t_tab3() ]
   #
for l_thread in l_threads:
   l_thread.start()




##################################################################


l_lastProcessed = 0


while True:
   l_thisProcessed = 0
      #
   for l_kMsg in l_kMsgs:
         #
      l_thisProcessed += 1
         #
      if (l_thisProcessed > l_lastProcessed):
         l_lastProcessed +=1
            #
         l_namespace = l_kMsg["namespace"]
         l_payload   = l_kMsg["payload"  ]
            #
         try:
            l_payload = ast.literal_eval(l_payload)
         except:
            l_payload = ast.literal_eval(
               "{ '_id' : -99, 'c1' : -99, 'c2' : -99 }")
         #
         #  This 'if' block handles inserts into mongoDB
         #  without an _id field. If not _id field is
         #  present, just use a hard coded value of -99.
         #
         if ( "_id" in l_payload ):
            l_justId = l_payload["_id"]
         else:
            l_justId = -99
         #
         #  Here we handle inserts and updates.
         #
         #  We chose not to program deletes, since we
         #  are mimicing enriching the data via Kafka,
         #  not actual maintainence of the data.
         #
         l_payload["_so"] = "Kafka"
            #
         if (l_namespace.startswith("t")):
            mdb[l_namespace].update( { "_id" : l_justId },
               { "$set" : l_payload }, upsert = True )
            print "  Kafka Publish - Success"
               #
            mdb.statistics.update( { "_id" : 0 },
               { "$inc" : { "kafka_pubs" : 1 } } )
                  #
   time.sleep(2)  #  Endless loop, sleep to throttle
   mdb.statistics.update( { "_id" : 0 },
      { "$inc" : { "kafka_ops" : 1 } } )

























