



import threading, time
from kafka import KafkaConsumer

l_msgs = []


class Consumer(threading.Thread):
   global msgs
      #
   daemon = True

   def run(self):
      consumer = KafkaConsumer("x_MDB", consumer_timeout_ms=5000 )
      # consumer = KafkaConsumer()
      # consumer.subscribe(pattern="t*")
            #
      for c in consumer:
         l_msgs.append(c)
         

threads = [ Consumer() ]

for t in threads:
   t.start()


while True:
   print "RRR"
   print l_msgs
   time.sleep(2)





