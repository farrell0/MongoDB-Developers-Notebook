#!/bin/bash


/opt/kafka_2.11-0.10.1.0/bin/kafka-topics.sh \
   --zookeeper localhost:2181 --delete --topic $1 --force \
   2> /dev/null > /dev/null






