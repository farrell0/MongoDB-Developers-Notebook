#!/usr/bin/bash


######################################################


rm -r /data/withAuth
   #
mkdir -p /data/withAuth
cd /data/withAuth
   #
mongod --fork --port 27000 --dbpath . --logpath logfile.1


######################################################


mongo --port 27000 <<EOF

use admin 

db.createUser(
   {
   "user"   : "my_admin",
   "pwd"    : "password",
   "roles"  : [ { "role" : "userAdminAnyDatabase", "db": "admin" } ]
   }
   )

use test_db9

db.createUser(
   {
   "user"    : "my_user1",
   "pwd"     : "password",
   "roles"   : [ ]
   }
   )
db.grantRolesToUser(
   "my_user1",
      [
      { "role" : "readWrite", "db" : "test_db9" }
      ]
   )

db.runCommand(
   {
   "createRole" : "viewFindOnly",
   "privileges" : 
      [ 
      { "resource" : 
         { "db" : "test_db9", "collection" : "my_view" }, "actions" : [ "find" ] }
      ],
    roles : []
   }
   )

db.createUser(
   {
   user: "my_user2",
   pwd: "password",
   roles: []
   }
   )
db.revokeRolesFromUser(
   "my_user2",
      [
      { "role" : "readWrite", "db" : "test_db9" }
      ]
   )
db.grantRolesToUser(
   "my_user2",
      [
      { "role" : "viewFindOnly", "db" : "test_db9" }
      ]
   )


use admin 
   #
db.shutdownServer()


EOF

sleep 10


######################################################


mongod --fork --port 27000 --dbpath . --logpath logfile.1 --auth
   #
ps -ef | grep mongod | grep 27000 | awk -F \
   " " '{print $2}' >> /data/withAuth/pids


######################################################


mongo --port 27000 --authenticationDatabase "admin" <<EOF


use test_db9
db.auth("my_user1", "password" )


db.my_coll.drop()
db.my_view.drop()


db.my_coll.insert(
   [
   { "name" : "Alice"    , "favColor" : "Blue"   , "age" : 41 },
   { "name" : "Bob"      , "favColor" : "Pink"   , "age" : 39 },
   { "name" : "Kate"     , "favColor" : "Green"  , "age" : 12 },
   { "name" : "William"  , "favColor" : "Yellow" , "age" : 41 }
   ])

db.createView("my_view", "my_coll",
   [
   { 
   "\$match" : { "age" : { "\$gt" : 18 } } 
   },
   { 
   "\$project" : { "age" : 0 }
   }
   ]);


EOF





