

from flask import Flask, render_template, request, jsonify
   #
import ast
import time
import threading

import kafka

l_allDataKafka = []


class get_allDataKafka(threading.Thread):
   global l_allDataKafka

   def run(self):
      l_kCons = kafka.KafkaConsumer("x_MDB",
         auto_offset_reset="earliest", 
         consumer_timeout_ms=2000,
         bootstrap_servers=["localhost:9092"], api_version=(0,10))
      while True:
         print "TTT 1"
         for l_mesg in l_kCons:
            print "TTT 2"
            l_recd = str(l_mesg.value)
            l_recd = ast.literal_eval(l_recd)
               #
            l_allDataKafka.append(l_recd)
         time.sleep(2)

l_threads = [ get_allDataKafka() ]
   #
for l_thread in l_threads:
    l_thread.start()


# l_kCons = kafka.KafkaConsumer(consumer_timeout_ms=50,
#    bootstrap_servers=["localhost:1234"], api_version=(0,10))
# l_kCons = kafka.KafkaConsumer(consumer_timeout_ms=50)
# l_kCons.subscribe(pattern="t*")





