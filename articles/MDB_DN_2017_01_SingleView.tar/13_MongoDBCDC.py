

#
#  This program reads from the mongoDB transaction log 
#  log file, and propagates changes into a Kafka topic.
#
#
#  Comments-
#
#  .  Version 0.67
#
#  .  This program was tested on CentOS 7 64 bit, and a
#     Community Edition MySQL version 5.6.34.
#
#     All database servers were local to one host, as was
#     this test program.
#




###################################################


#
#  Imports
#

import pymongo
import kafka
   #
import time                      #  Sleeps
import sys                       #  Exit on error
import re                        #  Regex




###################################################


#
#  Open our mongoDB connections-
#
#     1 to read the oplog
#     1 to update our activity collection
#
mongo_host1 = pymongo.MongoClient("localhost:27017")
mdb1        = mongo_host1.local
mongo_host2 = pymongo.MongoClient("localhost:27017")
mdb2        = mongo_host2.test_sv

#
#  The collections names we wish to read from the
#  oplog.
#
l_regx = re.compile("test_sv\.t", re.IGNORECASE)


#
#  Structure and command needed to initiate replica
#  set.
#
#  This needs to be done only one time in the life of
#  this mongoDB server.
#
l_conf = { "_id" : "sv_replset", "members" : [
      { "_id" : 0, "host" : "localhost:27017" }
      ] }
try:
   mdb1.command("replSetInitiate", l_conf)
except:
   pass

l_oplog = mdb1['oplog.rs']
if (l_oplog.count() == 0):
   print " "
   print "Error: oplog.rs collection does not exist."
   print " "
   sys.exit(1)
else:
   pass




###################################################
###################################################


#
#  Kafpa connection.
#
l_kProd = kafka.KafkaProducer()

#
#  We use this flag to pass thru the oplog one time,
#  and then start processing.
#
l_firstpass = 1

#
#  Cursor for the oplog.
#
l_oplog = mdb1.oplog.rs.find( { "ns" : l_regx ,
      "op" : { "$in" : [ "i", "d", "u" ] } },
   cursor_type=pymongo.CursorType.TAILABLE_AWAIT )

#
#  Our main loop; read the entries from the oplog.
#

print "  "
print "Running mongoDB CDC (13)  (Producer x_MDB)"
print "  "

while l_oplog.alive:
   for l_docu in l_oplog:
      if (l_firstpass == 1):
         pass
      else:
         l_message = {}
            #
         l_message["namespace"] = l_docu["ns"      ]
            #
         if   (l_docu["op"] == "i"):
            l_message["operation"] = "INS"
         elif (l_docu["op"] == "d"):
            l_message["operation"] = "DEL"
         elif (l_docu["op"] == "u"):
            l_message["operation"] = "UPD"
            #
         l_message["payload"] = str(l_docu["o"])
            #
         l_message = str(l_message)
            #
         l_kProd.send("x_MDB", l_message)
         print "  mongoDB Pull - Success"
            #
         mdb2.statistics.update( { "_id" : 0 },
            { "$inc" : { "mongo_pubs" : 1 } } )
   l_firstpass = 0
   time.sleep(2)
      #
   mdb2.statistics.update( { "_id" : 0 },
       { "$inc" : { "mongo_ops" : 1 } } )
   

   














