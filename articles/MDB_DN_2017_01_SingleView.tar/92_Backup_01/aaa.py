

import subprocess


l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t1", "{ '_id' : 4, 'k2' : 4 }"])
l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t1", "{ '_id' : 5, 'k2' : 5 }"])
l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t1", "{ '_id' : 6, 'k2' : 6 }"])
l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t2", "{ '_id' : 4, 'k2' : 4 }"])


