

import pymongo
   #
from pymongo import MongoClient


######################################################


cn = MongoClient("localhost:28000, localhost:28001, localhost:28002")
db = cn.test_db9

db.my_persons.drop()
db.my_airports.drop()

db.my_persons.insert( { "_id" : 1, "name" : "Shawn", "startAirport" : "JFK" } )

db.my_airports.insert( { "_id" : 2, "airport" : "JFK", "connects" : [ "BOS", "ORD" ] } )
db.my_airports.insert( { "_id" : 3, "airport" : "BOS", "connects" : [ "JFK", "PWM" ] } )
db.my_airports.insert( { "_id" : 4, "airport" : "ORD", "connects" : [ "JFK"        ] } )
db.my_airports.insert( { "_id" : 5, "airport" : "PWM", "connects" : [ "BOS", "LHR" ] } )
db.my_airports.insert( { "_id" : 6, "airport" : "LHR", "connects" : [ "PWM"        ] } )
db.my_airports.insert( { "_id" : 7, "airport" : "LHR", "connects" : [ "JJJ"        ] } )


######################################################


print "  "
print "Example: $graphLookup operator in aggregate."
print "  "
sss = list ( db.my_persons.aggregate(
   [
   {
   "$match" : { "name" : "Shawn" } 
   },
   {
   "$graphLookup" :
      {
      "from"                : "my_airports",
      "startWith"           : "$startAirport",
      "connectFromField"    : "connects",
      "connectToField"      : "airport",
         #
      "maxDepth"            : 6,
      "depthField"          : "numConns",
      "as"                  : "dest"
      }
   },
   {
   "$unwind"                : "$dest"
   },
   {
   "$project"               :
      {
      "_id"                 : 0,
      "name"                : 0,
      "startAirport"        : 0 # ,
         #
      # "dest._id"            : 1
      }
   },
   {
   "$match"                 : 
      {
      "dest.numConns"       : { "$gte" : 1 }
      }
   }
   ] ) )
for s in sss:
   print s


  

#
#  Outputs,
#
# Example: $graphLookup operator in aggregate.
#   
# {u'dest': {u'airport': u'BOS', u'_id': 3, u'connects': [u'JFK', u'PWM'], u'numConns': 1L}}
# {u'dest': {u'airport': u'ORD', u'_id': 4, u'connects': [u'JFK'], u'numConns': 1L}}
#
# {u'dest': {u'airport': u'PWM', u'_id': 5, u'connects': [u'BOS', u'LHR'], u'numConns': 2L}}
#
# {u'dest': {u'airport': u'LHR', u'_id': 7, u'connects': [u'JJJ'], u'numConns': 3L}}
# {u'dest': {u'airport': u'LHR', u'_id': 6, u'connects': [u'PWM'], u'numConns': 3L}}




