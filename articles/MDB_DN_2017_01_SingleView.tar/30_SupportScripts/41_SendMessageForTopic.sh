#!/bin/bash


echo $2 | kafka-console-producer.sh --broker-list \
   localhost:9092 --topic $1 2> /dev/null

