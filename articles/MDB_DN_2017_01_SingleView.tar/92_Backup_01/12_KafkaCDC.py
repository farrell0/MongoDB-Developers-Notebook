

#
#  This program reads from a Kafka topic and propagates
#  changes into a mongoDB database server instance.
#
#
#  Comments-
#
#  .  Version 0.63
#
#  .  This program was tested on CentOS 7 64 bit, and a
#     Kafka version 0.10.1.
#
#     All software is expected to be running on one host,
#     as was this test program.
#
#  .  This program loops, gets all of the Kafka topic
#     names starting with the letter 't', and listens
#     for messages, which are then upserted into mongoDB.
#
#  .  To push messages into a Kafka queue, run any of 
#     the following,
#
#        Add a topic
#
#           kafka-topics.sh --create --zookeeper localhost:2181 \
#              --replication-factor 1 --partitions 1 --topic t1
#
#        List topics
#
#           kafka-topics.sh --list --zookeeper localhost:2181
#
#        Delete topic
#
#           kafka-topics.sh --zookeeper localhost:2181 \
#              --delete --topic t1 --force
#
#        Produce a message
#
#           echo "Blah blah " | kafka-console-producer.sh \
#              --broker-list localhost:9092 --topic t1
#
#        Consume a message
#
#           kafka-console-consumer.sh --bootstrap-server \
#              localhost:9092 --topic t1 --from-beginning
#           kafka-console-consumer.sh --bootstrap-server \
#              localhost:9092 --topic t1
#




##################################################################
## Imports #######################################################


#
#  Need a,  pip install kafka-python for first import
#  to resolve.
#

import kafka 
import pymongo
   #
import time
import subprocess                 #  Run Linux programs
import ast                        #  Convert string to JSON




##################################################################
## Define functions ##############################################


#
#  Get list of topics inside Kafka
#

def get_topics():
   l_proc = subprocess.Popen([
      './30_SupportScripts/06_GetAllTopics.sh'],
      stdout=subprocess.PIPE, 
      stderr=subprocess.PIPE)
         #
   l_stdout, l_stderr = l_proc.communicate()
      #
   return l_stdout


#
#  Delete a topic inside Kafka
#
def delete_topic(p_arg1):
   l_proc = subprocess.Popen([
      './30_SupportScripts/07_DeleteATopic.sh', p_arg1])
         #
   l_proc.communicate()


#
#  Create a topic inside Kafka
#
def add_topic(p_arg1):
   if (p_arg1 in get_topics()):
      pass
   else:
      l_proc = subprocess.Popen([
         './30_SupportScripts/08_AddATopic.sh', p_arg1])
            #
      l_proc.communicate()




##################################################################
## Recycle Kafka #################################################


#
#  Nuke for morbid; stop and restart Kafka and its associated
#  Zookeeper.
#

print "  "
print "Recycle Kafka: (Begin, about 50 seconds)"
   #
l_proc = subprocess.Popen([
   './30_SupportScripts/04_StartAllKafka.sh', ' '])
l_proc.communicate()
   #
print "Recycle Kafka: (End)"


print "  "
print "Add Kafka topic: t1"
add_topic("t1")
print "Add Kafka topic: t2"
add_topic("t2")
print "Add Kafka topic: t3"
add_topic("t3")
print "Add Kafka topic: t4"
add_topic("t4")
print "Add Kafka topic: t5"
add_topic("t5")
print "Add Kafka topic: t6"
add_topic("t6")
print "Add Kafka topic: t7"
add_topic("t7")
print "Add Kafka topic: t8"
add_topic("t8")
print "  "
print "Add Kafka topic: x_MDB"
add_topic("x_MDB")
print "  "




##################################################################


mongo_host = pymongo.MongoClient("localhost:27017")
   #
mdb        = mongo_host.test_sv




##################################################################
## Program main ##################################################


print "  "
print "Running: Kafka CDC (12)"
print "  "


# l_kCons = kafka.KafkaConsumer(consumer_timeout_ms=50,
#    bootstrap_servers=["localhost:1234"], api_version=(0,10))
l_kCons = kafka.KafkaConsumer(consumer_timeout_ms=50)
l_kCons.subscribe(pattern="t*")


while True:
   try:
      for l_mesg in l_kCons:
         l_topic = l_mesg.topic
         l_value = l_mesg.value
            #
         if (l_topic.startswith("t")):
            if ( len(l_topic) < 1 ):
               l_topic = "t8"
            #
            #  Kafka returns l_value as a string, and we 
            #  need it as a Python dictionary.
            #
            try:
               l_value = ast.literal_eval(l_value)
            except:
               l_value = ast.literal_eval(
                  "{ '_id' : -99, 'c1' : -99, 'c2' : -99 }")
            #
            #  This 'if' block handles inserts into Kafka
            #  without an _id field. If not _id field is
            #  present, just use a hard coded value of -99.
            #
            if ( "_id" in l_value ):
               l_justId = l_value["_id"]
            else:
               l_justId = -99
            #
            #  Here we handle inserts and updates.
            #
            #  We chose not to program deletes, since we
            #  are mimicing enriching the data via Kafka,
            #  not actual maintainence of the data.
            #
            l_value["_so"] = "Kafka"
               #
            mdb[l_topic].update( { "_id" : l_justId },
               { "$set" : l_value }, upsert = True )
            print "  Kafka Push - Success"
                  #
            mdb.statistics.update( { "_id" : 0 },
               { "$inc" : { "kafka_pubs" : 1 } } )
   except:
      print "  Kafka: Saw fail on consumer loop. (Continuing)"
         #
   time.sleep(2)  #  Endless loop, sleep to throttle
      #
   mdb.statistics.update( { "_id" : 0 },
      { "$inc" : { "kafka_ops" : 1 } } )







