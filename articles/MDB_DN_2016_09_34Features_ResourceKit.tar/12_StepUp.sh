#!/bin/bash


#
#  Script to test the new stepUp() command.
#


#
#  From the previous step, we expect a 3 node
#  replica set with 28000 being the primary.
#
#
echo "  "
echo "Run rs.isMaster()"
echo "  "
mongo --port 28001 <<EOF

   rs.isMaster()

EOF


echo "  "
echo "Run db.adminCommand({replSetStepUp: 1})"
echo "  "
mongo --port 28001 <<EOF

   db.adminCommand({replSetStepUp: 1})

EOF

sleep 10


echo "  "
echo "Run rs.isMaster() again"
echo "  "
mongo --port 28001 <<EOF

   rs.isMaster()

EOF




