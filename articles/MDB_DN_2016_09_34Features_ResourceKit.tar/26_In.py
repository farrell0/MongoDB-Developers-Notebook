


import pymongo
   #
from pymongo import MongoClient


######################################################


cn = MongoClient("localhost:28000, localhost:28001, localhost:28002")
db = cn.test_db9

db.my_coll.drop()

db.my_coll.insert( {"state" : "XX", "zip" : 55555 } )
db.my_coll.insert( {"state" : "CO", "zip" : 66666 } )
db.my_coll.insert( {"state" : "WI", "zip" : 77777 } )
db.my_coll.insert( {"state" : "TX", "zip" : 88888 } )
db.my_coll.insert( {"state" : "YY", "zip" : 99999 } )


print " "
print "In a find."
print " "
sss = list ( db.my_coll.find( { "state" : { "$in" : [ "CO" , "WI" ] } } ) )
for s in sss:
   print s

print " "
print "In an aggregate."
print " "
sss = list ( db.my_coll.aggregate(
   [
   { "$match" :
      { "state" : { "$in" : [ "CO" , "WI", "TX", "NV" ] } } 
   }
   ] ) )
for s in sss:
   print s


# print " "
# print "In a find with regex."
# print " "
# sss = list ( db.my_coll.find( { "zip" : { "$in" : [ (^53), (^80) ] } } ) )
# for s in sss:
#    print s

   
print " "
print "In a find with numbers."
print " "
sss = list ( db.my_coll.find( { "zip" : { "$in" : [ (53), (88888) ] } } ) )
for s in sss:
   print s







