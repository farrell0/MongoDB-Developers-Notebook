

#
#  This program runs our Web front end, allowing SQL
#  DMLs into MySQL, publishes into Redis queues, and
#  reads from a mongoDB database server.
#
#  There are two additional programs in this directory
#  which should be running before running this program.
#  These 2 programs push changes from MySQL and Redis
#  into mongoDB.


import ast                #  Convert string to dictonary

import MySQLdb
import redis
import pymongo

import bottle             #  Simple Web app framework




######################################################
## Inits, Opens, and Sets ############################


#
#  Open our connection to the MySQL database
#  server.
#
db_conn = MySQLdb.connect(host="localhost", port=3306)
   #
db_curs = db_conn.cursor()
db_curs.execute("USE test_sv;")


#
#  Open our connection to Redis.
#
my_redis = redis.StrictRedis(
   host="localhost", port=6379, db=0)


#
#  Open our connection to the mongoDB database
#  server.
#
m_conn = pymongo.MongoClient("localhost:27017")
m_dbas = m_conn.test_sv


#
#  Modular (global) variables.
#
m_statistics  = ""
   #
m_collections = []
m_justKeys    = []
m_allDataHtml = []
   #
m_whichPage   = "li_overview"


#
#  By default bottle views whave to be in the cwd
#  or a directory titled, views. This statement
#  allow them to be in the named directory.
#
bottle.TEMPLATE_PATH.insert(0, "./45_views/")




######################################################
## Functions #########################################


#
#  We keep a collection with a single document.
#  This document maintains statistics from the
#  2 daemon processes we use to push changes
#  from MySQL and Redis into mongoDB.
#
def get_statistics():
   global m_statistics
      #
   m_statistics =  m_dbas.statistics.find_one()


#
#  Get a list of all collections in this database,
#  minus the collection titled, statistics.
#
def get_collections():
   global m_collections
      #
   del m_collections[:]
      #
   l_colls = m_dbas.collection_names()
      #
   for l_coll in l_colls:
      if (l_coll == "statistics"):
         pass
      else:
         m_collections.append(l_coll)
   m_collections.sort()


#
#  Get a list of all keys in all collections in 
#  this database.
#
#  We need this list later to populate an HTML
#  table with its rigid column names.
#
def get_justKeys():
   global m_collections
   global m_justKeys
      #
   del m_justKeys[:]
      #
   for l_coll in m_collections:
      #
      #  For each document in the given collection-
      #
      for l_docu in m_dbas[l_coll].find():
         for l_key in l_docu.keys():
            m_justKeys.append(l_key)
   #
   #  Append a key name for namespace (collection
   #  name), "ns".
   #
   m_justKeys.append("_cn")
   #
   #
   #  m_justKeys currently contains duplicates,
   #  and needs to be sorted.
   #
   m_justKeys = list(set(m_justKeys))
   m_justKeys.sort()


#
#  Get all of the data from this database in a 
#  normalized form, suitable for an HTML table.
#
def get_allDataHtml():
   global m_collections
   global m_justKeys
   global m_allDataHtml
      #
   del m_allDataHtml[:]
      #
   for l_coll in m_collections:
      for l_docu in m_dbas[l_coll].find():
         l_newDoc = { }
         for l_key in m_justKeys:
            if (l_key == "_cn"):
               l_newDoc[l_key] = l_coll
            else:
               if (l_key in l_docu):
                  l_newDoc[l_key] = l_docu[l_key]
               else:                 
                  l_newDoc[l_key] = ""
         m_allDataHtml.append(l_newDoc)
       



######################################################
## Page Handlers #####################################


#
#  This is our main page.
#
@bottle.route("/"                      ) 
def refresh_mdb():
   global m_whichPage
   global m_collections
   global m_statistics
   global m_justKeys
   global m_allDataHtml
      #
   get_statistics ()
   get_collections()
   get_justKeys()
   get_allDataHtml()
      #
   return bottle.template("40_main", 
      dict( h_whichPage=m_whichPage, h_collections=
      m_collections, h_statistics=m_statistics,
      h_justKeys=m_justKeys, h_allDataHtml=m_allDataHtml) )


#
#  This page is run from the Refresh button of the 
#  overview page. (More obvious than running refresh
#  from the Browser tool bar.)
#
@bottle.route("/overview_refresh", method="POST")
def ovreview_refresh():
   global m_whichPage
   m_whichPage =  "li_overview"
      #
   bottle.redirect("/")


#
#  This page is run from the MySQL execute a SQL
#  statement page.
#
@bottle.route("/sql_cmd", method="POST")
def sql_cmd():
   global m_whichPage
   m_whichPage =  "li_mysql"
      #
   m_sql_statement = bottle.request.forms.get("sql_statement")
   try:
      db_curs.execute( m_sql_statement )
      db_curs.execute( "COMMIT;"       )
   except:
      pass
   bottle.redirect("/")


#
#  This page is run from the Redis publish a message
#  statement page.
#
@bottle.route("/redis_cmd", method="POST")
def sql_cmd():
   global m_whichPage
   m_whichPage =  "li_redis"
      #
   m_name    = bottle.request.forms.get("q_name"   )
   m_message = bottle.request.forms.get("q_message")
   #
   #  Strip leading and trailing spaces. The ast lib
   #  didn't like those, and the HTML form was good
   #  at adding them.
   #
   m_name    = m_name.lstrip()
   m_name    = m_name.rstrip()
   m_message = m_message.lstrip()
   m_message = m_message.rstrip()
      #
   try:
      m_message = ast.literal_eval(m_message)
      my_redis.publish(m_name, m_message)
   except:
      pass
   bottle.redirect("/")


#
#  This page is run to view the documents that have
#  been placed in mongoDB.
#
@bottle.route("/mongodb_cmd", method="POST")
def mongodb_cmd():
   global m_whichPage
   m_whichPage =  "li_mongodb"
      #
   bottle.redirect("/")


#
#  This block allows our CSS and JS files to be
#  located in the named directory.
#
@bottle.route("/<filename:path>")
def send_static(filename):
    return bottle.static_file(filename, root="44_static/")




######################################################
## Main ##############################################


bottle.run(host='localhost', port=8080)














