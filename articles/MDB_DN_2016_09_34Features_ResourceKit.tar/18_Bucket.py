

import pymongo
   #
from pymongo import MongoClient


######################################################


cn = MongoClient("localhost:28000, localhost:28001, localhost:28002")
db = cn.test_db9

db.my_coll.drop()
   #
db.my_coll.insert( { "price" : 10 } )
db.my_coll.insert( { "price" : 10 } )
db.my_coll.insert( { "price" : 10 } )
db.my_coll.insert( { "price" : 20 } )
db.my_coll.insert( { "price" : 20 } )
db.my_coll.insert( { "price" : 50 } )
db.my_coll.insert( { "price" : -2 } )


######################################################


print "  "
print "Example: $bucket stage in aggregate."
print "  "
sss = list ( db.my_coll.aggregate(
   [
   {
   "$bucket" : 
      {
      "groupBy"      : "$price",
      "boundaries"   : [ 0, 22, 1000 ],    # Infinity would not work
      "default"      : "None of the above",
      "output"       :
         {
         "count"     : { "$sum"   : 1 },
         "members"   : { "$push"  : "$price" }
         }
      }
   }
   ] ) )
for s in sss:
   print s


