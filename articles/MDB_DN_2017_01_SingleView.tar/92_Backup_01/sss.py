

import subprocess


l_kMsgs = []

l_topics = [ "t1", "t2", "3", "t4",
   "t5", "t6", "t7", "t8", "x_MDB" ]


def get_newMessages():
   global l_kMsgs
   global l_topics
      #
   r_kMsgs = []
   #
   #  For each topic ..
   #  
   for l_topic in [ "t1", "t2", "3", "t4",
         "t5", "t6", "t7", "t8", "x_MDB" ]:
      #
      #  Count the number of messages we already
      #   have for this topic.
      #
      l_cntr1 = 0
         #
      for l_mesg in l_kMsgs:
         if (l_mesg["namespace"] == l_topic):
            l_cntr1 += 1
      #
      #  Get all messages for this topic.
      #
      l_proc = subprocess.Popen([
         './30_SupportScripts/40_GetMessagesForTopic.sh',
         l_topic], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
      #
      #  And now iterate over this list.
      #
      l_cntr2 = 0
         #
      for l_line in iter(l_proc.stdout.readline, ''):
         l_cntr2 += 1
            #
         if (l_cntr2 > l_cntr1):
            l_recd = {}
               #
            l_recd["namespace"] = l_topic
               #
            l_line = l_line.strip()
            l_recd["payload"]   = l_line
               #
            l_kMsgs.append(l_recd)
            r_kMsgs.append(l_recd)
            print "RRR"
               #
   return r_kMsgs


l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t1", "{ 'k1' : 4, 'k2' : 4 }"])
l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t1", "{ 'k1' : 5, 'k2' : 5 }"])
l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t1", "{ 'k1' : 6, 'k2' : 6 }"])
l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t2", "{ 'k1' : 4, 'k2' : 4 }"])


print "L1 - should be four"
for l_msgs in get_newMessages():
   print l_msgs


l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t1", "{ 'k1' : 7, 'k2' : 7 }"])
l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t1", "{ 'k1' : 8, 'k2' : 8 }"])
l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t2", "{ 'k1' : 5, 'k2' : 5 }"])
l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t2", "{ 'k1' : 6, 'k2' : 6 }"])

print "L2 - should be four new records"
for l_msgs in get_newMessages():
   print l_msgs






