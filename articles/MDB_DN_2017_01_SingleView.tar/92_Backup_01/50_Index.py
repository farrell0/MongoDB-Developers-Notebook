

#
#  This program runs our Web front end, allowing SQL
#  DMLs into MySQL, publishes into Redis queues, and
#  reads from a mongoDB database server.
#
#  There are two additional programs in this directory
#  which should be running before running this program.
#  These 2 programs push changes from MySQL and Redis
#  into mongoDB.




#############################################################
## Imports ##################################################


from flask import Flask, render_template, request, jsonify
   #
import os
import ast
import threading

import MySQLdb
import redis
import pymongo
import kafka




#############################################################
## Inits, Opens, and Sets ###################################


#
#  Instantiate flask object
#
m_app = Flask(__name__)


#  
#  Set flask defaults for locating files
#
m_templateDir = os.path.abspath("45_views" )
m_staticDir   = os.path.abspath("44_static")
   #
m_app.template_folder = m_templateDir
m_app.static_folder   = m_staticDir


#
#  Open our connection to the MySQL database
#  server.
#
db_conn = MySQLdb.connect(host="localhost", port=3306)
   #
db_curs = db_conn.cursor()
db_curs.execute("USE test_sv;")


#
#  Open our connection to Redis.
#
my_redis = redis.StrictRedis(
   host="localhost", port=6379, db=0)


#
#  Open our connections to Kafka.
#
#  Producer is used in tab4 to push messages
#  to Kafka.
#
#  Consumer is used to read messages on a 
#  Kafka topic. These messages were pushed 
#  there by a daemon which reads the mongoDB
#  oplog.
#
# l_kProd = kafka.KafkaProducer(bootstrap_servers=[
#    "localhost:1234"], api_version=(0,10))
l_kProd = kafka.KafkaProducer()
   #
# l_kCons = kafka.KafkaConsumer("x_MDB", consumer_timeout_ms=50,
#    bootstrap_servers=["localhost:1234"], api_version=(0,10))
# l_kCons.subscribe(pattern="x_MDB")
l_kCons = kafka.KafkaConsumer("x_MDB", consumer_timeout_ms=50)


#
#  Open our connection to the mongoDB database
#  server.
#
m_conn = pymongo.MongoClient("localhost:27017")
m_dbas = m_conn.test_sv

#
#  Global variable for records received from 
#  Kafka topic.
#
l_allDataKafka = []
   #
# l_rec = {}
# l_rec["namespace"] = "t1"
# l_rec["operation"] = "INS"
# l_rec["payload"  ] = "{ 'k1 : 88, 'k2' : 89 }"
# l_rec = str(l_rec)
#    #
# l_rec = ast.literal_eval(l_rec)
# l_allDataKafka.append(l_rec)
#    #
# l_rec = {}
# l_rec["namespace"] = "t2"
# l_rec["operation"] = "DEL"
# l_rec["payload"  ] = "{ 'k1 : 98, 'k2' : 99 }"
# l_rec = str(l_rec)
#    #
# l_rec = ast.literal_eval(l_rec)
# l_allDataKafka.append(l_rec)




#############################################################
## Functions ################################################


#
#  We keep a collection with a single document.
#  This document maintains statistics from the
#  2 daemon processes we use to push changes
#  from MySQL and Redis into mongoDB.
#
def get_statistics():
      #
   return m_dbas.statistics.find_one()


#
#  Get a list of all collections in this database,
#  minus the collection titled, statistics.
#
def get_collections():
   l_collections = []
      #
   l_colls = m_dbas.collection_names()
      #
   for l_coll in l_colls:
      if   (l_coll == "statistics"):
         pass
      elif (l_coll == "x_MDB"     ):
         pass
      else:
         l_collections.append(l_coll)
   l_collections.sort()
      #
   return l_collections


#
#  Get a list of all keys in all collections in 
#  this database.
#
#  We need this list later to populate an HTML
#  table with its rigid column names.
#
def get_justKeys():
   l_justKeys = []
      #
   for l_coll in get_collections():
      #
      #  For each document in the given collection-
      #
      for l_docu in m_dbas[l_coll].find():
         for l_key in l_docu.keys():
            l_justKeys.append(l_key)
   #
   #  Append a key name for namespace (collection
   #  name), "ns".
   #
   l_justKeys.append("_cn")
   #
   #
   #  l_justKeys currently contains duplicates,
   #  and needs to be sorted.
   #
   l_justKeys = list(set(l_justKeys))
   l_justKeys.sort()
      #
   return l_justKeys


#
#  Get all of the data from this database in a 
#  normalized form, suitable for an HTML table.
#
def get_allDataHtml():
   l_allDataHtml = []
      #
   for l_coll in get_collections():
      for l_docu in m_dbas[l_coll].find():
         l_newDoc = { }
         for l_key in get_justKeys():
            if (l_key == "_cn"):
               l_newDoc[l_key] = l_coll
            else:
               if (l_key in l_docu):
                  l_newDoc[l_key] = l_docu[l_key]
               else:                 
                  l_newDoc[l_key] = ""
         l_allDataHtml.append(l_newDoc)
   return l_allDataHtml




#############################################################
#############################################################


#
#  This is our main page.
#
@m_app.route('/')
def overview_tab():
   return render_template("50_Index.html")


#
#  This page is run from the Refresh button of the 
#  overview page. (More obvious than running refresh
#  from the Browser tool bar.)
#
@m_app.route('/_refresh_tab1')
def refresh_tab1():
   l_statistics = get_statistics()
      #
   return jsonify(l_statistics)


#
#  This page is run from the MySQL execute a SQL
#  statement page.
#
@m_app.route('/_execute_tab2')
def execute_tab2():
   l_sql_stmt = request.args.get('sql_stmt')
      #
   try:
      db_curs.execute( l_sql_stmt )
      db_curs.execute( "COMMIT;"  )
   except:
      pass
         #
   return jsonify()


#
#  This page is run from the Redis publish a message
#  statement page.
#
@m_app.route('/_execute_tab3')
def execute_tab3():
      #
   l_name    = request.args.get("q_name"   )
   l_message = request.args.get("q_message")
   #
   #  Strip leading and trailing spaces. The ast lib
   #  didn't like those, and the HTML form was good
   #  at adding them.
   #
   l_name    = l_name.lstrip()
   l_name    = l_name.rstrip()
   l_message = l_message.lstrip()
   l_message = l_message.rstrip()
      #
   try:
      l_message = ast.literal_eval(l_message)
      my_redis.publish(l_name, l_message)
   except:
      pass
   return jsonify()


#
#  This page is run from the Kafka publish a message
#  statement page.
#
@m_app.route('/_execute_tab4')
def execute_tab4():
      #
   global l_kProd
      #
   l_topic   = request.args.get("k_topic"  )
   l_message = request.args.get("k_message")
   #
   #  Strip leading and trailing spaces. The ast lib
   #  didn't like those, and the HTML form was good
   #  at adding them.
   #
   l_topic   = l_topic  .lstrip()
   l_topic   = l_topic  .rstrip()
   l_message = l_message.lstrip()
   l_message = l_message.rstrip()
   #
   #  Limitation in Python/Kafka lib ??
   #
   #  If I didn't do this, I got an error. Unicode
   #  object versus string ?
   #
   l_message = str(l_message)
   try:
      l_kProd.send(l_topic, l_message )
   except:
      pass
   return jsonify()


#
#  This page is run to view the documents that have
#  been placed in mongoDB.
#
@m_app.route('/_execute_tab5')
def execute_tab5():
   l_justKeys    = get_justKeys   ()
   l_allDataHtml = get_allDataHtml()
      #
   return jsonify(l_justKeys, l_allDataHtml)


#
#  This page is run to view the messages that have
#  been placed in Kafka.
#
@m_app.route('/_execute_tab6')
def execute_tab6():
   global l_allDataKafka
      #
   return jsonify(l_allDataKafka)




#############################################################
#############################################################


print "  "
print "Running Web App (50)"
print "  "


# class get_allDataKafka(threading.Thread):
#    global l_allDataKafka
# 
#    def run(self):
#       l_kCons = kafka.KafkaConsumer("x_MDB",
#          auto_offset_reset="earliest", 
#          consumer_timeout_ms=2000)
#       print "TTT 1"
#       for l_mesg in l_kCons:
#          print "TTT 2"
#          l_recd = str(l_mesg.value)
#          l_recd = ast.literal_eval(l_recd)
#             #
#          l_allDataKafka.append(l_recd)
# 
# l_threads = [ get_allDataKafka() ]
#    #
# for l_thread in l_threads:
#     l_thread.start()


if (__name__ == '__main__'):
   m_app.run(host = "localhost", port = int("8081"))








   



