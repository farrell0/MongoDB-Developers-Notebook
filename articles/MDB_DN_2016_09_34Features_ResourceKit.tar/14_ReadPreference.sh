#!/bin/bash


#
#  Script to test the new read preference options.
#


#
#  From the previous step, we expect a 3 node
#  replica set with 28000 being the primary.
#
#
echo "  "
echo "Setting up a 3 node replica set with 28000"
echo "being the primary."
echo "  "
13_CleanUpFrom11.sh 2> /dev/null
11_StepUpSetUp.sh   2> /dev/null


echo "  "
echo "Run a Python client requesting a secondary."
echo "  "

python <<EOF

import pymongo
from pymongo import MongoClient
from pymongo import ReadPreference

#
#  maxStaleness not in current version of PyMongo
#

cn = MongoClient("mongodb://localhost:28000,localhost:28001,localhost:28002/?readPreference=secondary&maxStalenessMS=3000000")
db = cn.local
   #
cc = db.me.find()
cc.next()

dd = cc.address

print dd

EOF













