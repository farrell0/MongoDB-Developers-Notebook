

import pymongo
   #
from pymongo import MongoClient


######################################################


cn = MongoClient("localhost:28000, localhost:28001, localhost:28002")
db = cn.test_db9

db.my_coll.drop()
   #
db.my_coll.insert( {
   "category"     : "Computer peripherals"   ,
   "sub-category" : "Mouse"                  ,
   "arrayOfVals"  : [ 1, 2, 3]
   } )
db.my_coll.insert( {
   "category"     : "Computer peripherals"   ,
   "sub-category" : "Mouse"                  ,
   "arrayOfVals"  : [ 1, 2]
   } )


######################################################


print "  "
print "Example: reduce operator in aggregate."
print "  "
sss = list ( db.my_coll.aggregate(
   [
   {
   "$project"             :
      {
      "_id"               : 0                 ,
      "category"          : 1,
         #
      "sumOf"             :
         {
         "$reduce"              : 
            {
            "input"             : "$arrayOfVals"       ,
            "initialValue"      : 0                    ,
            "in"                : { "$add" : [ "$$value", "$$this" ] }
            }
         },
      "multOf"            :
         {
         "$reduce"              : 
            {
            "input"             : "$arrayOfVals"       ,
            "initialValue"      : 1                    ,
            "in"                : { "$multiply" : [ "$$value", "$$this" ] }
            }
         },
      "both"              :
         {
         "$reduce"              : 
            {
            "input"             : "$arrayOfVals"       ,
            "initialValue"      : { "sumOf2" : 0, "multOf2" : 1  },
            "in"                : 
               {
               "sumOf2"      : { "$add"      : [ "$$value.sumOf2",  "$$this" ] },
               "multOf2"     : { "$multiply" : [ "$$value.multOf2", "$$this" ] }
               }
            }
         }
      }
   }
   ] ) )
for s in sss:
   print s























