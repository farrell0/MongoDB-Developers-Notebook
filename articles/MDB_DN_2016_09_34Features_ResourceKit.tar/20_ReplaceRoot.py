

import pymongo
   #
from pymongo import MongoClient


######################################################


cn = MongoClient("localhost:28000, localhost:28001, localhost:28002")
db = cn.test_db9

db.my_coll.drop()
   #
db.my_coll.insert( {
   "category"     : "Computer peripherals"   ,
   "sub-category" : "Mouse"                  ,
   "attributes"   :
      {
      "color"     : "red"        ,
      "plug"      : "USB"        ,
      "buttons"   : 3            
      }
   } )
db.my_coll.insert( {
   "category"     : "Computer peripherals"   ,
   "sub-category" : "Mouse"                  ,
   "attributes"   :
      {
      "color"     : "blue"       ,
      "plug"      : "USB"        ,
      "buttons"   : 2            
      }
   } )
db.my_coll.insert( {
   "category"     : "Computer peripherals"   ,
   "sub-category" : "Mouse"                  ,
   "attributes"   :
      {
      "color"     : "silver"     ,
      "plug"      : "PS2"        ,
      "buttons"   : 2            
      }
   } )
db.my_coll.insert( {
   "category"     : "Computer peripherals"   ,
   "sub-category" : "Monitor"                ,
   "attributes"   :
      {
      "size"      : 27           ,
      "res"       : "CGA"        
      }
   } )
db.my_coll.insert( {
   "category"     : "Computer peripherals"   ,
   "sub-category" : "Monitor"                ,
   "attributes"   :
      {
      "size"      : 29           ,
      "res"       : "VGA"       
      }
   } )


######################################################


print "  "
print "Example: $replaceRoot stage in aggregate."
print "  "
sss = list ( db.my_coll.aggregate(
   [
   {
   "$replaceRoot"       : 
      { "newRoot"       : "$attributes" }
   }
   ] ) )
for s in sss:
   print s


######################################################


print "  "
print "Example: similar to $replaceRoot stage in aggregate."
print "  "
sss = list ( db.my_coll.aggregate(
   [
   {
   "$project"           : 
      {
      "_id"             : 0                    ,
         #
      "category"        : 1                    ,
      "sub-category"    : 1                    ,
      "color"           : "$attributes.color"  ,
      "plug"            : "$attributes.plug"   ,
      "buttons"         : "$attributes.buttons",
      "size"            : "$attributes.size"   ,
      "res"             : "$attributes.res"
      }
   }
   ] ) )
for s in sss:
   print s


######################################################


#
#  The below did not work.
#
#  Can $exists be in a $switch ??
#


# print "  "
# print "Example: similar, more berbose to $replaceRoot stage in aggregate."
# print "  "
# sss = list ( db.my_coll.aggregate(
#    [
#    {
#    "$project"           : 
#       {
#       "_id"             : 0                    ,
#          #
#       "category"        : 1                    ,
#       "sub-category"    : 1                    ,
# 
#       "color"           : 
#          {
#          "$switch" :
#             {
#                "branches" :  
#                [
#                {
#                "case" :
#                   { "$exists" : [ "$category" ] } ,
#                "then" : "$attributes.color"
#                },
#                ],
#                "default" : " "        
#             }
#          },
# 
#       "plug"            : "$attributes.plug"   ,
#       "buttons"         : "$attributes.buttons",
#       "size"            : "$attributes.size"   ,
#       "res"             : "$attributes.res"
#       }
#    }
#    ] ) )
# for s in sss:
#    print s








