#!/bin/bash


/opt/kafka_2.11-0.10.1.0/bin/kafka-topics.sh \
   2> /dev/null                              \
   --list --zookeeper localhost:2181 | \
   grep -v "__consumer_offsets"      | \
   grep -v "marked for deletion"       





