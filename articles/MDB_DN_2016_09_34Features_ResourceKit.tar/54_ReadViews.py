

import pymongo
from pymongo import MongoClient

cn = MongoClient("mongodb://localhost:27000")

db = cn.test_db9
   #
db.authenticate("my_user1", "password" )

print "  "
print "Example (my_user1): find() from base collection."
print "  "
try:
   sss = list ( db.my_coll.find( {}, { "_id" : 0 } ) )
   for s in sss:
      print s
except:
   print "Can not read from base collection."


print "  "
print "Example (my_user1): find() from view."
print "  "
try:
   sss = list ( db.my_view.find( { "favColor" : "Blue" }, { "_id" : 0 } ) )
   for s in sss:
      print s
except:
   print "Can not read from view."


db.logout()
   #
db.authenticate("my_user2", "password" )

print "  "
print "Example (my_user2): find() from base collection."
print "  "
try:
   sss = list ( db.my_coll.find( {}, { "_id" : 0 } ) )
   for s in sss:
      print s
except:
   print "Can not read from base collection."


print "  "
print "Example (my_user2): find() from view."
print "  "
try:
   sss = list ( db.my_view.find( { "favColor" : "Blue" }, { "_id" : 0 } ) )
   for s in sss:
      print s
except:
   print "Can not read from view."




