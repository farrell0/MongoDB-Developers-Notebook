

#
#  This program reads from a Redis message queue,
#  and propagates changes into a mongoDB database
#  server instance.
#
#
#  Comments-
#
#  .  Version 0.67
#
#  .  This program was tested on CentOS 7 64 bit, and a
#     Redis version 2.8.19.
#
#     All software is expected to be running on one host,
#     as was this test program.
#
#  .  The Redis server uses the default port of 6379.
#
#     You can always recover this value via a,
#        redis-cli info
#
#  .  We replicate all received messages as an upsert
#     on the given key value. The received queue name
#     is used as the mongoDB collection name.
#
#  .  We also hard code our destination into MongoDB,
#     port 27017, database name test_sv.
#
#  .  The companion program to this program replicates
#     log file changes from a MySQL database server, and
#     that program drops the "test_sv" destination 
#     database upon program initialization.
#
#     We drop that database merely to avoid sprawl; that
#     is, as we test and test, the database would only
#     grow.
#
#  .  To put messages into a Redis message queue, open
#     a second terminal windows and perform steps similar
#     to,
#
#        redis-cli
#        publish t1 v1
#
#     Or when using JSON,
#        publish t1 "{ 'c1' : 2, 'c2' : 4 }"
#
#  .  A good doc page is located here,
#        https://github.com/andymccurdy/redis-py


import time
import sys
   #
import ast                #  Convert string to dictonary

import redis
import pymongo
   #
from pymongo import MongoClient


###################################################


my_redis = redis.StrictRedis(
   host="localhost", port=6379, db=0)

my_pubsub = my_redis.pubsub()

try:
   my_pubsub.psubscribe("*")
except:
   print "  "
   print "Error: Redis server not started"
   print "  "
   print "Start Redis with: systemctl start  redis.service"
   print "  "
   sys.exit(1)


mongo_host = MongoClient("localhost:27017")
   #
mdb        = mongo_host.test_sv


###################################################


#
#  This loop will run forever, checking for messages
#  on any named Redis queue. We sleep (n) seconds
#  between each check for messages.
#


print "  "
print "Running Redis CDC (11)"
print "  "

while True:
   l_msg = my_pubsub.get_message()
   if (l_msg):
      if (l_msg["type"] == "psubscribe"):
         pass
      else:
         l_table = l_msg["channel"]
            #
         if ( len(l_table) < 1):
            l_table = "t99"
               #
         l_data  = l_msg["data"   ]
         #
         #  Redis returns l_data as a string, and we 
         #  need it as a Python dictionary.
         #
         try:
            l_data = ast.literal_eval(l_data)
         except:
            l_data = ast.literal_eval(
               "{ '_id' : -99, 'c1' : -99, 'c2' : -99 }")
         #
         #  This 'if' block handles inserts into Redis
         #  without an _id field. If not _id field is
         #  present, just use a hard coded value of -99.
         #
         if ( "_id" in l_data ):
            l_justId = l_data["_id"]
         else:
            l_justId = -99
         #
         #  Here we handle inserts and updates.
         #
         #  We chose not to program deletes, since we
         #  are mimicing enriching the data via Redis,
         #  not actual maintainence of the data.
         #
         l_data["_so"] = "Redis"
            #
         mdb[l_table].update( { "_id" : l_justId },
            { "$set" : l_data }, upsert = True )
         print "  Redis Publish - Success"
               #
         mdb.statistics.update( { "_id" : 0 },
            { "$inc" : { "redis_pubs" : 1 } } )
   else:
      time.sleep(2)  #  Endless loop, sleep to throttle
         #
      mdb.statistics.update( { "_id" : 0 },
         { "$inc" : { "redis_ops" : 1 } } )











   






