

#
#  This program reads from the MySQL transaction log 
#  log file, and propagates changes into a mongoDB
#  database server instance.
#
#
#  Comments-
#
#  .  Version 0.58
#
#  .  This program was tested on CentOS 7 64 bit, and a
#     Community Edition MySQL version 5.6.34.
#
#     All database servers were local to one host, as was
#     this test program.
#
#  .  This program uses the open source BinLogStreamReader
#     available at,
#        https://github.com/noplay/python-mysql-replication
#
#  .  The MySQL database server uses the default port
#     number 3306, and expects a hard coded database
#     name of test_sv.
#
#     We only replicate SQL Inserts, Updates and Deletes,
#     although the  BinLogStreamReader supports most/all
#     MySQL events.
#
#     We do replicate all source table names into
#     the same named (collection) in mongoDB.
#
#  .  We also hard code our destination into MongoDB,
#     port 27017, database name test_sv.
#
#  .  We didn't make restart of this program terribly 
#     robust; basically we start reading the MySQL transaction
#     log file and replicate all observed changes.
#
#     A production ready version of this program would
#     be created to know where to restart.
#
#     This program also does not check or expectedly 
#     handle log file rotations in MySQL.
#
#     On restart, this program will read through the
#     entire MySQL transaction log file one time, [ then ]
#     start replicating. Thus, we only propagate changes 
#     that occur after this program starts.
#
#  .  To avoid sprawl on the mongoDB side, we start with 
#     a drop database (test_sv), which was the cheapest
#     and easiest way to start fresh, all empty collections.
#
#  .  The syntax to extract the primary key names from SQL
#     was do-able, but long. Thus, we cheated-
#
#     -  Inserts work.
#
#     -  Deletes use the entire width (entire set of column
#        names and values) to perform a remove on mongoDB.
#
#     -  Updates, we perform a delete then insert.
#
#        For production code, we should perform a proper 
#        modify on the mongoDB side. Again, we chose less
#        code because it worked and proved our point.
#
#   .  While not required, having a MySQL table with a 
#      column titled '_id' will insert that _id value 
#      into mongoDB as the _id field. This saves having
#      mongoDB system generated _id field which are
#      longer/more-complex than inserting simple integer
#      values.




###################################################


#
#  Imports
#

import time

import MySQLdb

from pymysqlreplication import BinLogStreamReader
   #
from pymysqlreplication.row_event import (
   DeleteRowsEvent, UpdateRowsEvent, WriteRowsEvent )

import pymongo
   #
from pymongo import MongoClient




###################################################


#
#  Setup the MySQL database, 8 tables (t1 - t8), all
#  with the same structure, cols (_id, c1, c2), all
#  integer, with the first column being the primary 
#  key.
#
#  A primary key is not required by this program.
#

db_conn = MySQLdb.connect(host="localhost", port=3306)
   #
db_curs = db_conn.cursor()

try:
   db_curs.execute("DROP   DATABASE test_sv;")
   db_curs.execute("COMMIT                 ;")
except:
   pass

db_curs.execute("CREATE DATABASE test_sv;")
db_curs.execute("USE             test_sv;")

l_tableNames = [ "t1", "t2", "t3", "t4", "t5", "t6", "t7", "t8" ]

for l_tableName in l_tableNames:
   db_curs.execute("CREATE TABLE " + l_tableName + 
      " (_id INT NOT NULL PRIMARY KEY, c1 INT, c2 INT);")

#
#  This insert is kind of bogus. If I started the
#  loop below with zero data in the MySQL transaction
#  log file, I got an error. Thus, insert one (bogus)
#  row to overcome.
#
db_curs.execute("INSERT INTO t8 VALUES (-99, -99, -99);")
db_curs.execute("COMMIT;")

db_conn.close()




###################################################


#
#  Set up connections we use throughout the remainder
#  of this program; the connector to the MySQL log
#  reader, and the connector to the destination database
#  hosted in mongoDB.
#


mysql_host = {'host': 'localhost', 'port': 3306 }

mysql_stream = BinLogStreamReader(connection_settings = mysql_host,
   only_events=[DeleteRowsEvent, WriteRowsEvent, UpdateRowsEvent],
    server_id = 1)


mongo_host = MongoClient("localhost:27017")
mongo_host.drop_database("test_sv")
   #
mdb        = mongo_host.test_sv

mdb.statistics.insert( { "_id" : 0, "mysql_ops" : 0,
   "mysql_ins" : 0, "mysql_upd" : 0, "mysql_del" : 0,
   "redis_ops" : 0, "redis_pubs" : 0 } )




###################################################

#
#  This loop allows us to read the entire MySQL
#  transaction log file and do nothing. In effect,
#  we leave with the latest log file entry and its
#  associated timestamp.
#
#  Then the second loop below begins pushing any
#  new changes to mongoDB.
#

for l_event in mysql_stream:
   g_timestamp = l_event.timestamp


###################################################


#
#  Our second loop, and the one that actually pushes
#  MySQL transaction log files changes into mongoDB.
#

while True:

   time.sleep(2)  #  Endless loop, sleep to throttle
      #
   for l_event in mysql_stream:

      #
      #  An event above can have multiple rows.
      #
      for l_row in l_event.rows:
         #
         #  Delete row event from the SQL side.
         #
         #  Because the utility we are using reads
         #  the MySQL transaction log file then
         #  terminates, we set and check the timestamp
         #  of the last transaction we ever processed.
         #
         if isinstance(l_event, DeleteRowsEvent):
            if (l_event.timestamp > g_timestamp):
               l_vals  = l_row["values"]
               l_table = l_event.table
                  #
               mdb[l_table].remove(l_vals)
                  #
               mdb.statistics.update( { "_id" : 0 },
                  { "$inc" : { "mysql_del" : 1 } } )
         #
         #  To save code, we delete then insert on 
         #  update. This could be omptimzed.
         #
         elif isinstance(l_event, UpdateRowsEvent):
            if (l_event.timestamp > g_timestamp):
               l_valsA = l_row["after_values"]
               l_valsB = l_row["before_values"]
                  #
               mdb[l_table].remove(l_valsB)
               mdb[l_table].insert(l_valsA)
                  #
               mdb.statistics.update( { "_id" : 0 },
                  { "$inc" : { "mysql_upd" : 1 } } )
         #
         #  Insert event.
         #
         elif isinstance(l_event, WriteRowsEvent):
            if (l_event.timestamp > g_timestamp):
               l_vals  = l_row["values"]
               l_table = l_event.table
                  #
               mdb[l_table].insert(l_vals)
                  #
               mdb.statistics.update( { "_id" : 0 },
                  { "$inc" : { "mysql_ins" : 1 } } )
         #
         #  Add more events here; create index, yadda.
         #

   g_timestamp = l_event.timestamp
      #
   mdb.statistics.update( { "_id" : 0 },
       { "$inc" : { "mysql_ops" : 1 } } )
   

mysql_stream.close()
   
   









 

