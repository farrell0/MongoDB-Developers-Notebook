

import pymongo
   #
from pymongo import MongoClient


######################################################


cn = MongoClient("localhost:28000, localhost:28001, localhost:28002")
db = cn.test_db9

db.my_coll.drop()
   #
db.my_coll.insert( {
   "category"     : "Computer peripherals"   ,
   "sub-category" : "Mouse"                  
   } )
db.my_coll.insert( {
   "category"     : "Computer peripherals"   ,
   "sub-category" : "Mouse"                  
   } )
db.my_coll.insert( {
   "category"     : "Computer peripherals"   ,
   "sub-category" : "Mouse"                  
   } )
db.my_coll.insert( {
   "category"     : "Computer peripherals"   ,
   "sub-category" : "Monitor"                
   } )
db.my_coll.insert( {
   "category"     : "Computer peripherals"   ,
   "sub-category" : "Monitor"                
   } )


######################################################


print "  "
print "Example: (string) stages in aggregate."
print "  "
sss = list ( db.my_coll.aggregate(
   [
   {
   "$project"             : 
      {
      "_id"               : 0,
      "category"          : 1,
      "cat1"              : { "$substrBytes" : [ "$category", 0, 8 ] },
      "cat2"              : { "$substrCP"    : [ "$category", 0, 8 ] }
      }
   }
   ] ) )
for s in sss:
   print s























