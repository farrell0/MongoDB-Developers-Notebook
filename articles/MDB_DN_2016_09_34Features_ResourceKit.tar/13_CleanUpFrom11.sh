#!/bin/bash


#
#  This is clean up from the script above, number 11.
#


export DB_DIR=/data/rs_manual9

for t in ` cat $DB_DIR/pids 2> /dev/null`
   do
   kill -9 $t
   done

rm -fr $DB_DIR 2> /dev/null





