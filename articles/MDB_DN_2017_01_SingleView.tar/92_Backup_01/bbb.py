

import subprocess


l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t1", "{ '_id' : 7, 'k2' : 7 }"])
l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t1", "{ '_id' : 8, 'k2' : 8 }"])
l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t2", "{ '_id' : 5, 'k2' : 5 }"])
l_proc = subprocess.Popen([
   './30_SupportScripts/41_SendMessageForTopic.sh',
   "t2", "{ '_id' : 6, 'k2' : 6 }"])







