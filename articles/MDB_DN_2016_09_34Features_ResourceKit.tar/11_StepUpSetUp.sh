#!/bin/bash


#
#  Script to test the new stepUp() command.
#


#
#  Make the directories ..
#
export DB_DIR=/data/rs_manual9
   #
rm -rf $DB_DIR
mkdir -p $DB_DIR/node0 $DB_DIR/node1 $DB_DIR/node2
touch $DB_DIR/pids
   #
chmod -R 777 $DB_DIR


#
#  Make 3 servers
#
echo "  "
echo "Make 3 servers."
echo "  "
mongod --dbpath $DB_DIR/node0          \
    --logpath $DB_DIR/node0/logfile    \
   --port 28000 --fork --noauth        \
   --replSet "abc" --smallfiles --wiredTigerCacheSizeGB 1
ps -ef | grep mongod | grep 28000 | awk -F " " '{print $2}' >> $DB_DIR/pids
mongod --dbpath $DB_DIR/node1          \
    --logpath $DB_DIR/node1/logfile    \
   --port 28001 --fork --noauth        \
   --replSet "abc" --smallfiles --wiredTigerCacheSizeGB 1
ps -ef | grep mongod | grep 28001 | awk -F " " '{print $2}' >> $DB_DIR/pids
mongod --dbpath $DB_DIR/node2          \
    --logpath $DB_DIR/node2/logfile    \
   --port 28002 --fork --noauth        \
   --replSet "abc" --smallfiles --wiredTigerCacheSizeGB 1
ps -ef | grep mongod | grep 28002 | awk -F " " '{print $2}' >> $DB_DIR/pids

sleep 10


#
#  Initiate a replica set
#
echo "  "
echo "Initiate a replica set."
echo "  "
mongo --port 28000 <<EOF

   var cfg = { "_id" : "abc", members : [
      { "_id" : 0, "host" : "localhost:28000" }
      ] }

   rs.initiate( cfg )

EOF

sleep 10


#
#  Add second and third members
#
echo "  "
echo "Add a second and third members to the replica set."
echo "  "
mongo --port 28000 <<EOF

   rs.add("localhost:28001")
   rs.add("localhost:28002")

EOF

sleep 10


#
#  Check replcia set status
#
mongo --port 28000 <<EOF

   rs.isMaster()

EOF

echo "  "
echo "** Notice port 28000 is the primary."
echo "  "








